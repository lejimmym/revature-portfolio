package com.spring.demo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.spring.demo.domain.Student;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;

@Repository 
public class EntityManagerStudentDAO implements StudentDAO{
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public Student insert(Student student) {
        entityManager.persist(student);
        return student;
    }

    @Override 
    public List<Student> findAll() {
        TypedQuery<Student> query = entityManager.createNamedQuery(
            "SELECT student FROM student ORDER BY student.id",
            Student.class);
            return query.getResultList();
    }

    @Override
    public Student findById(int id) {
        return entityManager.find(Student.class, id);
    }
}

//Want to have a clean separation of concerns
//Wants the API layer to not call the DAO directly..